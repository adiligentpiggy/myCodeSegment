package test.x86;


public class TEST {

	/**  
     * @param args  
     */  
    public static void main(String[] args) {  
    	
  
        System.out.println(TestJNA.INSTANCE.add(2,2));  
    }  
	
}
